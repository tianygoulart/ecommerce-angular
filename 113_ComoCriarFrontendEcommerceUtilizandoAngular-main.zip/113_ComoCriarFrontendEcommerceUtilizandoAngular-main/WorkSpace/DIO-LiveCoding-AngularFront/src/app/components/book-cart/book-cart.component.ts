import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-cart',
  templateUrl: './book-cart.component.html',
  styleUrls: ['./book-cart.component.css']
})
export class BookCartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
