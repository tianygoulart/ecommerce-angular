# LABs

## 113_ComoCriarFrontendEcommerceUtilizandoAngular

Como criar um front-end de um e-commerce utilizando Angular

DESCRIÇÃO
Vamos iniciar o desenvolvimento de nosso e-commerce de livros, estruturando nosso projeto back-end e criando a nossa API de listagem de produtos.

Angular - Front-End - Básico
ESPECIALISTA
#### Nathalia Corrêa
IT Analyst, BTG Pactual
 

https://web.dio.me/lab/como-criar-um-front-end-de-um-e-commerce-utilizando-angular/learning/a08526cd-f630-4126-a9cf-045539a61496
